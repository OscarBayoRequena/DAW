

package domingo.fechas;
import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;  
import java.time.format.FormatStyle;

import java.time.temporal.ChronoField; 


/**
 * Clase ejemplo de utilización de fechas con las clases LocalDateTime
 * @author Domingo M.
 */
public class Fechas {
    
    public static void main(String[] args) {
            
       // creaFecha();
        
       // extraeInfo();
        
        operarDias();
       
        
    }  // fin del main
    
    

    /**Metodo que genera una fecha y la muestra con y sin formato mediante el
     * uso de la clase DateTimeFormatter
     */
    public static void creaFecha(){
        
        LocalDateTime ahora = LocalDateTime.now();  //metodo que devuelve la fecha y hora actual del sistema
        
        System.out.println("\n Antes de dar formato: " + ahora);  
        
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");  
        
        String fechaConFormato = ahora.format(formato);  
        
        System.out.println("\n Después de dar formato: " + fechaConFormato); 
        
      //  System.out.println(fechaConFormato);
        
    }
    
    /**Metodo que muestra como extraer informacion de un objeto LocalDateTime
     * mediante el uso de la clase ChronoField
     */
    public static void extraeInfo(){
        
        LocalDateTime fechaHora = LocalDateTime.of(2020, 2, 29, 15, 56);  //metodo que establece unafecha y hora dadas como enteros
        
        System.out.println(fechaHora.get(ChronoField.DAY_OF_WEEK));   // ChronoFiekd es un Enum del paquete java.time.temporal
        
        System.out.println(fechaHora.get(ChronoField.DAY_OF_YEAR));  
        
        System.out.println(fechaHora.get(ChronoField.DAY_OF_MONTH));  
        
        System.out.println(fechaHora.get(ChronoField.HOUR_OF_DAY));  
        
        System.out.println(fechaHora.get(ChronoField.MINUTE_OF_DAY));  
        
      
    
    
    }
    
    /**Metodo que nos muestra como es posible operar con fechas
     * 
     */
    public static void operarDias(){
        LocalDateTime fecha = LocalDateTime.of(2021, 1, 8, 10, 34);  
        
        LocalDateTime fechaResta = fecha.minusDays(30);     //Crea un nuevo objeto. Resto 30 dias al objeto fecha
        
        LocalDateTime fechaSuma = fecha.plusDays(30);       //Crea un nuevo objeto. Suma 30 dias al objeto fecha
        
        System.out.println("\n Resta Antes de dar formato: " + fechaResta);  
        
        System.out.println("\n Suma Antes de dar formato: " + fechaSuma);
        
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");  
        
        String formatoResta = fechaResta.format(format);
        
        String formatoSuma = fechaSuma.format(format);
        
        System.out.println("\n Resta Después de dar formato: " + formatoResta ); 
        
        System.out.println("\n Suma Después de dar formato: " + formatoSuma );
    
    
    
    }
 
    
} // fin de la clase


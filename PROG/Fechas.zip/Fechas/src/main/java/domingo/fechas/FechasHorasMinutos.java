

package domingo.fechas;

import java.time.*; // Este paquete contiene LocalDate, LocalTime y LocalDateTime.
import java.time.format.*;  // Este paquete contiene DateTimeFormatter.



/**
 * Clase ejemplo de utilización de fechas con las clases LocalDateTime
 * @author Domingo M.
 */
public class FechasHorasMinutos {
    
    public static void main(String[] args) {
        
      //  noMezclarTipos();
        
      //  formatoIso();
        
        System.out.println("\n\n");
        
        fechaDesdeCadena();
        
        System.out.println("\n\n");
        
        System.out.println("Hemos terminado");
        
        
    } // fin del main
    
    
    
    
    /**
     * No se deben de mezclar los tipos LocaleDate con LocaleTime y LocaleDateTime ya que son clases sin relación 
     * Si se puede instanciar unas dentro de otras.
     */
    static void noMezclarTipos(){
    
    
   //     LocalTime ahora = LocalDate.now();        error: incompatible types: LocalDate cannot be converted to LocalTime
   //     System.out.println(ahora);
        
   //     LocalDateTime ahora2 = LocalDate.now();       error: incompatible types: LocalDate cannot be converted to LocalDateTime
   //     System.out.println(ahora2);
    
        LocalDate hoy = LocalDate.now();
        LocalTime ahora = LocalTime.now();
        
        LocalDateTime fecha = LocalDateTime.of(hoy, ahora);   // Crea un objeto LocaleDateTime a partir de otros objetos LocaleDate y LocaleTime
        
        System.out.println(fecha);
    
    }
    
    /**
     * Existen diferentes tipos de formato que se pueden utilizar con fechas, desde las proporcionadas por la propia API
     * hasta las creadas por los usuarios a través de un patron.
     */
    public static void formatoIso(){
    
        LocalDateTime fecha = LocalDateTime.now();
        
        DateTimeFormatter isoFecha = DateTimeFormatter.ISO_LOCAL_DATE;
        System.out.println(fecha.format(isoFecha));
      
        DateTimeFormatter isoHora = DateTimeFormatter.ISO_LOCAL_TIME;
        System.out.println(fecha.format(isoHora));
        
        DateTimeFormatter isoFechaHora = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        System.out.println(fecha.format(isoFechaHora));
        
        // imprimimos la fecha con formato local SHORT; MEDIUM; LONG; FULL
        
        DateTimeFormatter fechaIsoCorta = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
        DateTimeFormatter fechaIsoMedio = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
        DateTimeFormatter fechaIsoCompleta = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
        
        System.out.println("\n\nImpresiones de FECHA");
        System.out.println("Short   "+ fecha.format(fechaIsoCorta));
        System.out.println("Medium  " + fecha.format(fechaIsoMedio));
        System.out.println("Full    "+ fecha.format(fechaIsoCompleta));
      
                 // imprimimos la hora con formato local SHORT; MEDIUM; LONG; FULL
        
        DateTimeFormatter horaIsoCorta = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT);
        DateTimeFormatter HoraIsoMedio = DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM);
        DateTimeFormatter horaIsoLarga = DateTimeFormatter.ofLocalizedTime(FormatStyle.LONG);
        
        System.out.println("\n\nImpresiones de HORAS");
        System.out.println("Short   " + fecha.format(horaIsoCorta));
        System.out.println("Medium  "+ fecha.format(HoraIsoMedio));
        //System.out.println("Long    "+ fecha.format(horaIsoLarga));
   
                // imprimimos la feca y hora con formato local SHORT; MEDIUM; LONG; FULL
        
        DateTimeFormatter fechaHoraIsoCorta = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT);
        DateTimeFormatter fechaHoraIsoMedio = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM);
        DateTimeFormatter fechaHoraIsoLarga = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG);
        
        System.out.println("\n\nImpresiones de FECHAS y HORAS");
        System.out.println("Short   " + fecha.format(fechaHoraIsoCorta));
        System.out.println("Medium  "+ fecha.format(fechaHoraIsoMedio));
        // System.out.println("Long    "+ fecha.format(fechaHoraIsoLarga));       
       
       
                 // Especificamos nosotros un formato concreto con un patron
                 
       DateTimeFormatter fechaConPatron = DateTimeFormatter.ofPattern(("dd-MM-yyyy"));
       System.out.println("\n\nFecha con un patron específico:  " + fecha.format(fechaConPatron));
    
    
    }
    
    /**
     * Se puede instanciar un objeto LocalDateTime desde una cadena o string mediante el metodo parse
     */
    public static void fechaDesdeCadena(){
        
        //LocalDateTime hoy = LocalDateTime.parse("2021-01-06T21:55:02.44");
        LocalDateTime hoy = LocalDateTime.now();
        
        DateTimeFormatter f = DateTimeFormatter.ofPattern("'Hoy es' d 'del mes' M 'del año' yyyy. 'Son las' kk 'horas'.");
        
        System.out.println(hoy.format(f));
    
    
    }

} // fin de la clase




